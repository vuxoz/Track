# KoinScan — Deploy ke Vercel

Versi **serverless**: frontend statis + 4 API Python (`/api/feed`, `/api/sinyal`,
`/api/movers`, `/api/analisa`). Analisa dihitung **on-demand** per request dengan
cache in-memory per instance — tanpa background thread (serverless tidak mengizinkan),
sehingga data selalu dihitung dari pump.fun/DexScreener langsung saat dibuka.

## Isi
- `api/_lib.py` — inti: ambil pump.fun + DexScreener, skor, analisa AI, movers, sinyal
- `api/feed.py`, `api/sinyal.py`, `api/movers.py`, `api/analisa.py` — endpoint
- `public/` — 12 halaman + style.css + app.js + nav.js (identik versi lokal v27)
- `vercel.json` — routing & rewrite path bersih (`/sinyal` → `sinyal.html`)

## Cara deploy
1. Install CLI: `npm i -g vercel`
2. `cd vercel && vercel --prod`
3. Login saat diminta, jawab default (project name `koinscan`, framework `other`).

Atau via Git: push folder ini ke GitHub → import di vercel.com → Deploy.

## Catatan
- Gratis tier cukup: cache in-memory membuat request berulang murah.
- Tick 20 detik & scan 10 menit hanya ada di versi server lokal (VPS).
  Di Vercel, data "live" = dihitung ulang tiap kali halaman memuat (auto-refresh 30-60 dtk).
- Jika pump.fun membatasi IP serverless (kadang region US diblok), tambahkan
  `REGIONS=iad1` atau set env var `PUMP_BASE` ke mirror API.

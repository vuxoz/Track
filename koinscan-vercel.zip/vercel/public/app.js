// app.js — util bersama + pemuat feed
const fmt$ = n => n >= 1e9 ? '$'+(n/1e9).toFixed(2)+'B'
  : n >= 1e6 ? '$'+(n/1e6).toFixed(2)+'M'
  : n >= 1e3 ? '$'+(n/1e3).toFixed(1)+'K' : '$'+(n||0).toFixed(0);
const pct = v => v == null ? '–'
  : `<span class="${v >= 0 ? 'up' : 'down'}">${v >= 0 ? '+' : ''}${v.toFixed(1)}%</span>`;

async function ambilFeed() {
  const f = await (await fetch('/api/feed')).json();
  if (!f.menarik_dibeli) throw new Error('scanning');
  document.getElementById('st-total').textContent = f.total_dipindai ?? '–';
  document.getElementById('st-time').textContent = f.waktu ?? '–';
  return f;
}

function isi(tableId, list, rowFn, kosongMsg) {
  const tb = document.querySelector(tableId + ' tbody');
  if (!tb) return;
  tb.innerHTML = list.length
    ? list.map(rowFn).join('')
    : `<tr><td colspan="11" class="kosong">${kosongMsg}</td></tr>`;
}

// logo koin — hanya gambar; tanpa gambar = teks saja
function logoHTML(k, cls) {
  if (!k.logo && !k.img) return ''; // tanpa logo → teks saja
  const u = (k.logo || k.img).replace(/'/g, '');
  // multi-gateway: kalau sumber gagal, coba gateway IPFS berikutnya; habis semua → hapus (teks saja)
  let chain = JSON.stringify(ipfsChain(u)).replace(/"/g, '&quot;');
  return '<img class="' + cls + '" src="' + u + '" alt="" loading="lazy" ' +
    'data-chain="' + chain + '" ' +
    'onerror="cobaGatewayBerikutnya(this)">';
}
// rantai gateway IPFS: url asli → ipfs.io → 4everland → dweb.link → hapus
function ipfsChain(u) {
  const m = u.match(/ipfs\/(Qm[1-9A-HJ-NP-Za-km-z]{44}|baf[a-z0-9]+)/);
  const alt = m ? [
    'https://ipfs.io/ipfs/' + m[1],
    'https://4everland.io/ipfs/' + m[1],
    'https://dweb.link/ipfs/' + m[1],
    'https://cloudflare-ipfs.com/ipfs/' + m[1]
  ] : [];
  return [u, ...alt.filter(x => x !== u)];
}
function cobaGatewayBerikutnya(img) {
  let chain = [];
  try { chain = JSON.parse(img.dataset.chain || '[]'); } catch (e) {}
  if (chain.length > 1) {
    img.dataset.chain = JSON.stringify(chain.slice(1));
    img.src = chain[1];
  } else {
    img.remove(); // habis semua gateway → teks saja, tanpa pengganti
  }
}

// TICKER berjalan ala pump.fun - semua koin live dalam satu strip
function tkItem(k) {
  const h = k.h24 != null ? k.h24 : (k.h1 != null ? k.h1 : null);
  const cls = h == null ? 'dim2' : (h >= 0 ? 'up' : 'down');
  const txt = h == null ? '' : ((h>=0?'+':'') + h.toFixed(1) + '%');
  const logo = (k.logo||k.img)
    ? '<img src="'+(k.logo||k.img)+'" alt="" onerror="this.remove()">'
    : '';
  return '<span class="tk">'+logo+'<b>'+k.simbol+'</b>'+
    '<span class="pct '+cls+'">'+txt+'</span></span>';
}
async function pasangTicker(sel) {
  const host = document.querySelector(sel);
  if (!host) return;
  try {
    const f = await (await fetch('/api/feed')).json();
    const semua = [];
    for (const kat of ['menarik_dibeli','pumpfun_baru','pumpfun_stonk','solana_alternatif'])
      for (const k of (f[kat]||[])) semua.push(k);
    const unik = {}; for (const k of semua) if (k.mint) unik[k.mint] = k;
    const top = Object.values(unik).filter(k=>k.h24!=null||k.h1!=null)
      .sort((a,b)=>Math.abs(b.h24||b.h1||0)-Math.abs(a.h24||a.h1||0)).slice(0,18);
    if (!top.length) { host.style.display='none'; return; }
    const html = top.map(tkItem).join('');
    host.innerHTML = '<div class="ticker-dalam">'+html+html+'</div>';
  } catch(e) { host.style.display='none'; }
}


/* ===== Analisa AI (modal global) ===== */
function bukaAnalisa(mint, ev){
  if(ev) ev.stopPropagation();
  let m = document.getElementById('modal-ai');
  if(!m){
    m = document.createElement('div'); m.id='modal-ai';
    m.style.cssText='position:fixed;inset:0;background:rgba(10,14,20,.55);z-index:999;display:flex;align-items:center;justify-content:center;padding:16px';
    m.onclick = e => { if(e.target===m) m.remove(); };
    document.body.appendChild(m);
  }
  m.innerHTML = '<div style="background:#fff;border-radius:14px;max-width:520px;width:100%;padding:18px;font-family:inherit"><div class="dim2">🤖 Menganalisa…</div></div>';
  fetch('/api/analisa?mint='+mint).then(r=>r.json()).then(a=>{
    if(a.error){ m.innerHTML='<div style="background:#fff;border-radius:14px;max-width:520px;width:100%;padding:18px">Koin belum ada di data analisa.</div>'; return; }
    const warna = a.skor_ai>=75?'#0e9e68':a.skor_ai>=60?'#16c784':a.skor_ai>=45?'#eab308':a.skor_ai>=30?'#f97316':'#ea3943';
    const li = (arr,ikon)=>arr.map(x=>`<li style="margin:3px 0">${ikon} ${x}</li>`).join('');
    m.innerHTML = `<div style="background:#fff;border-radius:14px;max-width:520px;width:100%;padding:18px;max-height:85vh;overflow:auto">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
        <b style="font-size:15px">🤖 Analisa AI — ${a.simbol||''}</b>
        <button onclick="document.getElementById('modal-ai').remove()" style="border:0;background:#f1f3f7;border-radius:8px;padding:4px 10px;cursor:pointer">✕</button>
      </div>
      <div style="display:flex;align-items:center;gap:12px;margin:10px 0">
        <div style="width:64px;height:64px;border-radius:50%;background:${warna};color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;font-weight:800">
          <span style="font-size:20px">${a.skor_ai}</span><span style="font-size:9px">/100</span>
        </div>
        <div>
          <div style="font-weight:800;color:${warna}">${a.putusan}</div>
          <div class="dim2">MC $${(a.mc||0).toLocaleString('en-US')}</div>
        </div>
      </div>
      ${a.kekuatan.length?`<ul style="padding-left:18px;margin:8px 0;color:#0e9e68">${li(a.kekuatan,'✅')}</ul>`:''}
      ${a.hati_hati.length?`<ul style="padding-left:18px;margin:8px 0;color:#b45309">${li(a.hati_hati,'⚠️')}</ul>`:''}
      <div style="background:#f4f6fb;border-radius:10px;padding:10px;font-size:12.5px;line-height:1.5;margin-top:8px">${a.narasi}</div>
    </div>`;
  }).catch(e=>{ m.innerHTML='<div style="background:#fff;border-radius:14px;padding:18px">Gagal memuat analisa.</div>'; });
}

document.addEventListener('click', e => {
  const td = e.target.closest('td.skor');
  if (!td) return;
  const tr = td.closest('tr[data-mint]');
  if (!tr) return;
  e.preventDefault(); e.stopPropagation();
  bukaAnalisa(tr.dataset.mint, null);
}, true);

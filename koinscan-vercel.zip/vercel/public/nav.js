// nav.js — navigasi KoinScan v5: ikon SVG per menu + logo brand baru
const IKON = {
  "/": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M12 2l2.9 6.3 6.9.7-5.2 4.6 1.5 6.8L12 16.9 5.9 20.4l1.5-6.8L2.2 9l6.9-.7z"/></svg>',
  "/pumpfun": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M12 2C7 2 3 6 3 11c0 3 1.5 5.7 4 7.3V22h3v-2h4v2h3v-3.7c2.5-1.6 4-4.3 4-7.3 0-5-4-9-9-9zM8.5 12a1.8 1.8 0 110-3.6 1.8 1.8 0 010 3.6zm7 0a1.8 1.8 0 110-3.6 1.8 1.8 0 010 3.6z"/></svg>',
  "/graduated": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M12 3L1 8l11 5 9-4.1V15h2V8L12 3zM5 13.2V17c0 1.7 3.1 3 7 3s7-1.3 7-3v-3.8l-7 3.2-7-3.2z"/></svg>',
  "/alternatif": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M21 11.5a8.4 8.4 0 01-1 4 8.5 8.5 0 01-7.5 4.5 8.4 8.4 0 01-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 01-1-4 8.5 8.5 0 014.5-7.5 8.4 8.4 0 014-1h.5A8.5 8.5 0 0121 11z"/></svg>',
  "/akumulasi": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M20.8 9.5c-1.7-2.6-4.9-4.2-8.8-4.2S5 7 3.2 9.5c-.9 1.4-.9 3.6 0 5 1.7 2.6 4.9 4.2 8.8 4.2s7.1-1.6 8.8-4.2c.9-1.4.9-3.6 0-5zM12 16.2a4.2 4.2 0 110-8.4 4.2 4.2 0 010 8.4zm0-6.7a2.5 2.5 0 100 5 2.5 2.5 0 000-5z"/></svg>',
  "/top": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M3.5 18.5L9 13l4 4 7.4-8.3-1.5-1.3-6.1 6.9-4-4-6.8 6.8zM14 6h6v6h-2V9.4l-1.4 1.5-1.4-1.4L16.6 8H14z"/></svg>',
  "/grafik": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M3 3h2v16h16v2H3V3zm4 12l3.5-4 3 3L19 7l2 2-8 8-3-3-3 3.5V15z"/></svg>',
  "/cek": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M15.5 14h-.8l-.3-.3a6.5 6.5 0 10-.7.7l.3.3v.8l5 5 1.5-1.5-5-5zm-6 0a4.5 4.5 0 110-9 4.5 4.5 0 010 9z"/></svg>',
  "/watchlist": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M17 3H7a2 2 0 00-2 2v16l7-3 7 3V5a2 2 0 00-2-2z"/></svg>',
  "/sinyal": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M13 2v7h6l-8 13v-8H5l8-12z"/></svg>',
  "/scam": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M12 2L2 19h20L12 2zm1 13h-2v2h2v-2zm0-6h-2v4h2V9z"/></svg>',
  "/multichain": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M12 2a10 10 0 100 20 10 10 0 000-20zm7.9 9h-3.4a15.7 15.7 0 00-1.2-5.6A8 8 0 0119.9 11zM12 4c.8 1.2 1.9 3.6 2.4 7H9.6C10.1 7.6 11.2 5.2 12 4zM4.1 13h3.4c.2 2.2.6 4.1 1.2 5.6A8 8 0 014.1 13zm3.4-2H4.1a8 8 0 014.6-5.6C8.1 6.9 7.7 8.8 7.5 11zM12 20c-.8-1.2-1.9-3.6-2.4-7h4.8c-.5 3.4-1.6 5.8-2.4 7zm3.3-1.4c.6-1.5 1-3.4 1.2-5.6h3.4a8 8 0 01-4.6 5.6zM16.5 11c-.2-2.2-.6-4.1-1.2-5.6a8 8 0 014.6 5.6h-3.4z"/></svg>',
  "/tentang": '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M12 2a10 10 0 100 20 10 10 0 000-20zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>',
};
const LOGO_BRAND = '<svg viewBox="0 0 48 48" width="34" height="34" aria-hidden="true">'
 + '<defs>'
 + '<linearGradient id="lgBg" x1="0" y1="0" x2="1" y2="1">'
 + '<stop offset="0" stop-color="#2b3140"/><stop offset=".55" stop-color="#1d2230"/><stop offset="1" stop-color="#12151f"/></linearGradient>'
 + '<linearGradient id="lgCoin" x1="0" y1="0" x2="0" y2="1">'
 + '<stop offset="0" stop-color="#ffe9a3"/><stop offset="1" stop-color="#f7b32b"/></linearGradient>'
 + '<linearGradient id="lgBolt" x1="0" y1="0" x2="0" y2="1">'
 + '<stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#c9d2e3"/></linearGradient>'
 + '</defs>'
 + '<rect x="2" y="2" width="44" height="44" rx="13" fill="url(#lgBg)"/>'
 + '<rect x="2.8" y="2.8" width="42.4" height="42.4" rx="12.2" fill="none" stroke="rgba(255,255,255,.22)" stroke-width="1.3"/>'
 + '<circle cx="24" cy="25" r="14" fill="url(#lgCoin)" stroke="#c98d12" stroke-width="1.4"/>'
 + '<circle cx="24" cy="25" r="10.5" fill="none" stroke="rgba(138,92,0,.35)" stroke-width="1.2"/>'
 + '<path d="M26.5 14.5L19 27h4.4l-1.9 9.5L29 24h-4.6l2.1-9.5z" fill="url(#lgBolt)" stroke="#8a5c00" stroke-width=".8" stroke-linejoin="round"/>'
 + '<path d="M8 20c2.5-2 5-2.4 7.5-1M32.5 31.5c2.5.8 4.8.5 7-1" stroke="rgba(255,255,255,.45)" stroke-width="1.8" stroke-linecap="round" fill="none"/>'
 + '<circle cx="38.5" cy="10.5" r="6" fill="#f7b32b" stroke="#fff" stroke-width="1.6"/>'
 + '<path d="M38.5 7.3l1 2.1 2.3.3-1.7 1.6.4 2.3-2-1.1-2 1.1.4-2.3-1.7-1.6 2.3-.3z" fill="#3a2f10"/>'
 + '</svg>';

const KELOMPOK_NAV = [
  ["PASAR", [
    ["/", "Beranda"],
    ["/pumpfun", "Pump.fun Baru"],
    ["/graduated", "Graduated"],
    ["/alternatif", "DEX Lainnya"],
    ["/akumulasi", "Akumulasi"],
    ["/top", "Top Movers"],
  ]],
  ["ALAT", [
    ["/grafik", "Grafik"],
    ["/cek", "Cek Koin"],
    ["/watchlist", "Watchlist"],
    ["/sinyal", "Sinyal"],
  ]],
  ["MULTI-CHAIN", [
    ["/multichain", "Multi-Chain"],
  ]],
  ["RISIKO", [
    ["/scam", "Terfilter Scam"],
    ["/tentang", "Tentang"],
  ]],
];

// pasang logo brand di header (h1 a) — sekali
(function () {
  const a = document.querySelector("header h1 a");
  if (a && !a.querySelector("svg")) {
    a.insertAdjacentHTML("afterbegin", LOGO_BRAND);
  }
})();

const nav = document.getElementById('nav');
if (nav) {
  const wrap = document.createElement('nav');
  wrap.className = 'nav';
  for (const [nama, daftar] of KELOMPOK_NAV) {
    for (const [href, label] of daftar) {
      const a = document.createElement('a');
      a.href = href;
      a.innerHTML = (IKON[href] || '') + '<span>' + label + '</span>';
      a.className = 'nav-a';
      if (location.pathname === href) a.classList.add('aktif');
      wrap.appendChild(a);
    }
  }
  nav.appendChild(wrap);
}

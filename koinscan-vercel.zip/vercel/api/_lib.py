# KoinScan — library inti untuk Vercel serverless (stdlib only).
# Serverless = stateless: setiap panggilan fetch live ke pump.fun/DEX lalu hitung.
# Cache in-memory per instance (hangat ±1-15 menit) supaya hemat & cepat.
import json, time, urllib.request, urllib.error

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
      "Accept": "application/json"}
PUMP = "https://frontend-api-v3.pump.fun"

_cache = {}

def cache_get(key, ttl):
    v = _cache.get(key)
    if v and time.time() - v[0] < ttl:
        return v[1]
    return None

def cache_set(key, val):
    _cache[key] = (time.time(), val)

def http_json(url, timeout=10):
    req = urllib.request.Request(url, headers=UA)
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read())

def get_json(url, timeout=10):
    req = urllib.request.Request(url, headers=UA)
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read())


# ---------- pump.fun ----------
def pump_ambil(sort="market_cap", limit=100):
    """Ambil koin bonding curve pump.fun. sort: created_timestamp | market_cap."""
    key = f"pump:{sort}:{limit}"
    hit = cache_get(key, 25)
    if hit is not None:
        return hit
    try:
        data = http_json(f"{PUMP}/coins?sort={sort}&order=DESC&limit={limit}")
        cache_set(key, data)
        return data
    except Exception:
        return []

def num(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0

def fmt_koin(c):
    """Normalisasi satu koin pump.fun."""
    mc = num(c.get("usd_market_cap"))
    created = num(c.get("created_timestamp")) / 1000
    umur = (time.time() - created) / 3600 if created else None
    return {
        "simbol": c.get("symbol", "?"),
        "nama": (c.get("name") or "?")[:24],
        "mint": c.get("mint", ""),
        "sumber": "pumpfun",
        "img": (c.get("image_uri") or "").strip(),
        "mc": mc,
        "complete": bool(c.get("complete")),
        "umur_jam": round(umur, 1) if umur else None,
        "replies": int(c.get("reply_count") or 0),
        "live": bool(c.get("is_currently_live")),
        "creator": c.get("creator", ""),
    }

def skor_pump(k):
    """Skor kualitas 0-100 (metode riset: MC, umur, sosial, status)."""
    s = 0.0
    mc = k["mc"]
    if 30_000 <= mc <= 500_000: s += 30
    elif 5_000 <= mc < 30_000: s += 20
    elif 500_000 < mc <= 2_000_000: s += 15
    u = k.get("umur_jam")
    if u is not None:
        s += 20 if u < 6 else 12 if u < 24 else 5 if u < 72 else 0
    s += min(15, k.get("replies", 0) / 10 * 15)
    s += 10 if k.get("live") else 0
    if k.get("complete"): s += 15
    elif 50_000 <= mc < 69_000: s += 12
    return round(max(0, min(100, s)), 1)


# ---------- DexScreener (koin DEX / graduated) ----------
def dex_trending():
    key = "dex:trend"
    hit = cache_get(key, 30)
    if hit is not None:
        return hit
    try:
        data = http_json("https://api.dexscreener.com/latest/dex/search?q=solana%20meme")
        pairs = []
        for p in (data.get("pairs") or []):
            if (p.get("chainId") or "") != "solana":
                continue
            bt = p.get("baseToken") or {}
            tx = p.get("txns") or {}
            h1 = tx.get("h1") or {}
            h24 = tx.get("h24") or {}
            liq = num((p.get("liquidity") or {}).get("usd"))
            if liq < 5_000:
                continue
            chg = p.get("priceChange") or {}
            pairs.append({
                "simbol": bt.get("symbol", "?"),
                "nama": (bt.get("name") or "?")[:24],
                "mint": bt.get("address", ""),
                "sumber": "dexscreener",
                "img": (bt.get("logoURI") or "").strip(),
                "mc": num(p.get("marketCap")) or num(p.get("fdv")),
                "liq": liq,
                "h1": num(chg.get("h1")),
                "h24": num(chg.get("h24")),
                "vol24": num(p.get("volume", {}).get("h24")),
                "tekanan_beli": round(num(h1.get("buys")) / max(1, num(h1.get("buys")) + num(h1.get("sells"))) * 100) if (h1.get("buys") or h1.get("sells")) else None,
            })
        pairs.sort(key=lambda x: -(x.get("vol24") or 0))
        pairs = pairs[:60]
        cache_set(key, pairs)
        return pairs
    except Exception:
        return []

def skor_dex(k):
    s = 0.0
    mc = k.get("mc") or 0
    if 100_000 <= mc <= 5_000_000: s += 25
    elif mc > 5_000_000: s += 12
    rasio = (k.get("liq") or 0) / mc if mc else 0
    if rasio >= 0.1: s += 20
    elif rasio >= 0.04: s += 12
    vol = k.get("vol24") or 0
    if mc and vol / mc >= 1: s += 20
    elif mc and vol / mc >= 0.3: s += 12
    if (k.get("h1") or 0) >= 10: s += 15
    elif (k.get("h1") or 0) >= 3: s += 8
    tb = k.get("tekanan_beli")
    if tb is not None:
        if tb >= 60: s += 15
        elif tb >= 50: s += 8
    if (k.get("h24") or 0) >= 50: s += 10
    return round(max(0, min(100, s)), 1)


# ---------- analisa AI (heuristik riset) ----------
def analisa_ai(k):
    """Narasi + skor AI dari metrik koin (metode riset multi-faktor)."""
    skor = k.get("skor") or 50
    kekuatan, hati = [], []
    mc = k.get("mc") or 0
    umur = k.get("umur_jam")
    if umur is not None and umur < 1:
        kekuatan.append("sangat baru — peluang awal (risiko tinggi)")
    if 30_000 <= mc <= 500_000:
        kekuatan.append("MC di zona pertumbuhan ideal ($30K–$500K)")
    if (k.get("replies") or 0) >= 30:
        kekuatan.append(f"komunitas aktif ({k['replies']} komentar)")
    if (k.get("tekanan_beli") or 0) >= 60:
        kekuatan.append(f"tekanan beli dominan ({k['tekanan_beli']}%)")
    if (k.get("h1") or 0) >= 10:
        kekuatan.append(f"momentum 1 jam kuat (+{k['h1']:.0f}%)")
    liq = k.get("liq") or 0
    if mc and liq and liq / mc < 0.05:
        hati.append("likuiditas tipis — sulit keluar posisi")
    if mc and (k.get("vol24") or 0) < mc * 0.05:
        hati.append("volume sangat rendah — minat melemah")
    if umur is not None and umur > 72:
        hati.append("umur >3 hari — fase jenuh")
    if skor >= 75: putusan = "SANGAT POTENSIAL"
    elif skor >= 60: putusan = "POTENSIAL"
    elif skor >= 45: putusan = "NETRAL — TUNGGU"
    elif skor >= 30: putusan = "HATI-HATI"
    else: putusan = "HINDARI"
    bagian = [f"{k.get('simbol','?')} MC ${mc:,.0f}" +
              (f", umur {umur:.1f} jam" if umur is not None else "")]
    if kekuatan: bagian.append("Poin kuat: " + "; ".join(kekuatan[:3]) + ".")
    if hati: bagian.append("Perhatian: " + "; ".join(hati[:3]) + ".")
    bagian.append(f"Kesimpulan AI: {putusan} (skor {skor}/100). Analisa otomatis — selalu DYOR.")
    return {"skor_ai": skor, "putusan": putusan,
            "kekuatan": kekuatan, "hati_hati": hati,
            "narasi": " ".join(bagian)}


# ---------- feed gabungan ----------
def feed():
    key = "feed"
    hit = cache_get(key, 20)
    if hit is not None:
        return hit
    pump_new = [fmt_koin(c) for c in pump_ambil("created_timestamp", 100)]
    pump_mc  = [fmt_koin(c) for c in pump_ambil("market_cap", 100)]
    seen, pump_unik = set(), []
    for k in pump_new + pump_mc:
        if k["mint"] and k["mint"] not in seen:
            seen.add(k["mint"]); pump_unik.append(k)
    for k in pump_unik:
        k["skor"] = skor_pump(k)
    koin_baru = [k for k in pump_unik if not k.get("complete")]
    koin_stonk = [k for k in pump_unik if k.get("complete")]
    dex = dex_trending()
    for k in dex:
        k["skor"] = skor_dex(k)
    def bersihkan(lst, n=50):
        seen2, out = set(), []
        for k in sorted(lst, key=lambda x: -(x.get("skor") or 0)):
            key_ = k.get("mint") or (k.get("simbol"), k.get("sumber"))
            if key_ in seen2: continue
            seen2.add(key_); out.append(k)
        return out[:n]
    menarik = bersihkan(koin_baru + koin_stonk + dex)
    feed = {
        "ts": time.time(),
        "waktu": time.strftime("%Y-%m-%d %H:%M:%S"),
        "jaringan": "solana",
        "total_dipindai": len(pump_unik) + len(dex),
        "menarik_dibeli": menarik,
        "pumpfun_baru": bersihkan(koin_baru),
        "pumpfun_stonk": bersihkan(koin_stonk),
        "solana_alternatif": bersihkan(dex),
        "akumulasi": bersihkan([k for k in (koin_baru + koin_stonk + dex)
                                if (k.get("tekanan_beli") or 0) >= 60 and (k.get("h1") or 0) > 0], 20),
        "interval_analisa": 60,
        "catatan": "Analisa dihitung on-demand di Vercel; MC live dihitung saat request.",
    }
    cache_set(key, feed)
    return feed

def movers():
    """Top movers: kenaikan MC relatif terhadap posisi awal (pakai ATH pump.fun sbg patokan analisa)."""
    key = "movers"
    hit = cache_get(key, 30)
    if hit is not None:
        return hit
    baris = []
    for c in pump_ambil("market_cap", 100):
        mc = num(c.get("usd_market_cap"))
        ath = num(c.get("ath_market_cap")) or mc
        # proksi "sejak dianalisa": MC vs $10K baseline + kualitas naik
        baseline = 10_000
        if mc >= baseline * 1.5 and mc >= 15_000:
            baris.append({
                "mint": c.get("mint"), "simbol": c.get("symbol", "?"),
                "nama": (c.get("name") or "")[:24],
                "img": (c.get("image_uri") or "").strip(),
                "mc_awal": baseline, "mc": round(mc),
                "kenaikan_pct": min(9_999, round((mc / baseline - 1) * 100, 1)),
                "growth": round(mc / baseline, 2),
                "rsi_ath": round(mc / ath * 100, 1) if ath else None,
            })
    baris.sort(key=lambda x: -x["growth"])
    out = {"ts": time.time(), "total": len(baris), "movers": baris[:50]}
    cache_set(key, out)
    return out

def sinyal_dari(feed_data):
    """Turunkan sinyal dari kondisi kini (serverless tanpa state antar-request)."""
    ev = []
    now = time.time()
    for k in (feed_data.get("menarik_dibeli") or [])[:30]:
        g = None
        h1 = k.get("h1") or 0
        if k.get("complete"):
            ev.append({"tipe": "GRADUATED", "ikon": "🎓", **k,
                       "waktu": now, "ket": "lulus ke pumpswap/DEX"})
        elif h1 >= 20:
            ev.append({"tipe": "MELONJAK", "ikon": "🚀", **k,
                       "waktu": now, "ket": f"melonjak +{h1:.0f}% dalam 1 jam"})
        elif h1 >= 5:
            ev.append({"tipe": "SPIKE", "ikon": "🌋", **k,
                       "waktu": now, "ket": f"naik +{h1:.0f}% dalam 1 jam"})
        elif 50_000 <= (k.get("mc") or 0) < 69_000:
            ev.append({"tipe": "DEKAT-LULUS", "ikon": "🎯", **k,
                       "waktu": now, "ket": f"{(k['mc']/69_000)*100:.0f}% menuju graduation"})
        elif (k.get("umur_jam") or 99) < 0.5 and (k.get("mc") or 0) > 8_000:
            ev.append({"tipe": "BARU-RILIS", "ikon": "🆕", **k,
                       "waktu": now, "ket": f"koin baru, MC ${k['mc']:,.0f}"})
    for e in ev:
        a = analisa_ai(e)
        e.update({"skor_ai": a["skor_ai"], "putusan_ai": a["putusan"],
                  "ai_kekuatan": a["kekuatan"], "ai_hati": a["hati_hati"],
                  "mc_live": round(e.get("mc") or 0), "proyek": {}})
    return ev[:60]

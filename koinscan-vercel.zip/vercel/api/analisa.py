import json, sys, os, time
from urllib.parse import urlparse, parse_qs
sys.path.insert(0, os.path.dirname(__file__))
from _lib import feed, analisa_ai
from http.server import BaseHTTPRequestHandler

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        q = parse_qs(urlparse(self.path).query)
        mint = (q.get("mint") or [""])[0]
        f = feed()
        koin = None
        for kat in ("menarik_dibeli","pumpfun_baru","pumpfun_stonk","solana_alternatif"):
            for k in (f.get(kat) or []):
                if k.get("mint") == mint:
                    koin = k; break
            if koin: break
        if not koin:
            koin = {"mint": mint, "simbol": "?", "mc": 0, "skor": 0}
        a = analisa_ai(koin)
        a["mint"] = mint
        a["ts"] = time.time()
        body = json.dumps(a, ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

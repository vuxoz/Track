import json, sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from _lib import feed, sinyal_dari
from http.server import BaseHTTPRequestHandler

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        f = feed()
        d = {"ts": time.time(), "waktu": f["waktu"], "sinyal": sinyal_dari(f),
             "tick": {"total_dilacak_tick": f["total_dipindai"], "aktif_2menit": f["total_dipindai"],
                      "interval": 60},
             "interval_analisa": 60}
        body = json.dumps(d, ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)
